var a = " 4 5 6 ";
a.trim();
