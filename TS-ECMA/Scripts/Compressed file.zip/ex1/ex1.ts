var a : string = " 4 5 6 "
a.trim()
