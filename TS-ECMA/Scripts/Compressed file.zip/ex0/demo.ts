let cadena: number = 12345
console.log(cadena.trim())