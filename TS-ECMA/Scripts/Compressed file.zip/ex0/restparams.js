"use strict";
function print(first, second, ...allOther) {
    console.log(allOther);
}
print('java', 'scala');
print('java', 'scala', 'ceylon', 'javascript');
