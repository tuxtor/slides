"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mascota_1 = require("./mascota");
console.log("La mascota es " + mascota_1.default);
