import duke from "./mascota";

console.log(`La mascota es ${duke}`)