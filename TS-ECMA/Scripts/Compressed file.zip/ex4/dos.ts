import {penguin} from "./uno"

var bar = penguin

console.log(`El ave es ${bar}`)