var mascota = 'Java Duke';
export default mascota;