import {penguin as ave} from "./uno"

var bar = ave

console.log(`El ave es ${ave}`)