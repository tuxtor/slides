"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mascota = 'Java Duke';
exports.default = mascota;
