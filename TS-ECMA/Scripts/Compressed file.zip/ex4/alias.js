"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var uno_1 = require("./uno");
var bar = uno_1.penguin;
console.log("El ave es " + uno_1.penguin);
