var penguin: any;

// Takes any and all types
penguin = 'Tuz'; //String
penguin = 123; //Number

console.log(penguin)