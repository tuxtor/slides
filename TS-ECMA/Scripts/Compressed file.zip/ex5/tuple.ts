var nameNumber: [string, number];

nameNumber = ['Jenny', 8675309];

//nameNumber = ['Jenny', '867-5309'];

console.log(nameNumber);