var person: {
    nombre: string,
    apellido: string
}

var person = {
    nombre: 'Victor',
    apellido: 'Orozco'
}

console.log(person);